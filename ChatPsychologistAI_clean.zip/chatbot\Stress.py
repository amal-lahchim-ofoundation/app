from Disorder import Disorder

class Stress(Disorder):
    def __init__(self, name, filename):
        super().__init__(name, filename)
        self.add_session(1, " ")
        
        self.add_session(2, " ")
        
        self.add_session(3, " ")
        
        self.add_session(4, " ")
        
        self.add_session(5, " ")
        
        self.add_session(6, " ")
        
        self.add_session(7, " ")
        
        self.add_session(8, " ")


