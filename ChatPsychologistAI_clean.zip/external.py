import os
import io
import math
import tempfile
import requests
import torch
from flask import Flask, request, jsonify
from pydub import AudioSegment
from faster_whisper import WhisperModel
from pyannote.audio import Pipeline
from functools import wraps
from dotenv import load_dotenv
from concurrent.futures import ThreadPoolExecutor, as_completed
import psutil

# --- Utilities ---
def log_memory(tag=""):
    process = psutil.Process(os.getpid())
    mem_mb = process.memory_info().rss / (1024 * 1024)
    print(f"[{tag}] 🧠 RAM Usage: {mem_mb:.2f} MB")

def save_text_file(filename, content):
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)

# --- Flask App Setup ---
load_dotenv()
app = Flask(__name__)
whisper_model = None
diarization_pipeline = None

# --- API Key Protection ---
def require_api_key(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        provided_key = request.headers.get("X-API-Key")
        if not provided_key or provided_key != os.getenv("MY_SECRET_API_KEY"):
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated

# --- Whisper Loader ---
def load_whisper():
    global whisper_model
    if whisper_model is None:
        whisper_model = WhisperModel("small", device="cuda", compute_type="float16")
        print("✅ Whisper loaded")
    return whisper_model

# --- PyAnnote Loader ---
def load_diarization():
    global diarization_pipeline
    if diarization_pipeline is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        diarization_pipeline = Pipeline.from_pretrained(
            "pyannote/speaker-diarization-3.1",
            use_auth_token=os.getenv("PYANNOTE_AUDIO_AUTH_KEY")
        ).to(device)
        print(f"🧠 PyAnnote loaded on {device}")
    return diarization_pipeline

# --- Helpers ---
def stream_audio_from_firebase(url):
    r = requests.get(url, stream=True)
    r.raise_for_status()
    return io.BytesIO(r.content)

def convert_to_wav(audio_data: io.BytesIO):
    audio = AudioSegment.from_file(audio_data)
    wav = io.BytesIO()
    audio.export(wav, format="wav")
    wav.seek(0)
    return wav

def split_audio(wav_audio: io.BytesIO, chunk_duration_ms=120000):
    audio = AudioSegment.from_file(wav_audio, format="wav")
    chunks = []
    for i in range(math.ceil(len(audio) / chunk_duration_ms)):
        chunk = audio[i * chunk_duration_ms:(i + 1) * chunk_duration_ms]
        chunk_bytes = io.BytesIO()
        chunk.export(chunk_bytes, format="wav", codec="pcm_s16le")
        chunk_bytes.seek(0)
        chunks.append(chunk_bytes)
    return chunks

# --- Speaker Aligner ---
class SpeakerAligner:
    def align(self, timestamps, diarization):
        speaker_transcriptions = []
        last_diarization_end = self.get_last_segment(diarization).end

        for chunk in timestamps:
            chunk_start = chunk['timestamp'][0]
            chunk_end = chunk['timestamp'][1]
            segment_text = chunk['text']

            if chunk_end is None:
                chunk_end = last_diarization_end if last_diarization_end else chunk_start

            best_match = self.find_best_match(diarization, chunk_start, chunk_end)
            if best_match:
                speaker = best_match[2]
                speaker_transcriptions.append((speaker, chunk_start, chunk_end, segment_text))

        return self.merge_consecutive_segments(speaker_transcriptions)

    def find_best_match(self, diarization, start_time, end_time):
        best_match = None
        max_intersection = 0
        for turn, _, speaker in diarization.itertracks(yield_label=True):
            intersection_start = max(start_time, turn.start)
            intersection_end = min(end_time, turn.end)
            if intersection_start < intersection_end:
                intersection_length = intersection_end - intersection_start
                if intersection_length > max_intersection:
                    max_intersection = intersection_length
                    best_match = (turn.start, turn.end, speaker)
        return best_match

    def merge_consecutive_segments(self, segments):
        merged_segments = []
        previous = None
        for segment in segments:
            if previous and previous[0] == segment[0]:
                previous = (previous[0], previous[1], segment[2], previous[3] + " " + segment[3])
            else:
                if previous:
                    merged_segments.append(previous)
                previous = segment
        if previous:
            merged_segments.append(previous)
        return merged_segments

    def get_last_segment(self, diarization):
        last = None
        for seg in diarization.itersegments():
            last = seg
        return last

# --- Main Endpoint ---
@app.route("/process", methods=["POST"])
@require_api_key
def process_audio():
    data = request.get_json()
    firebase_url = data.get("firebase_url")
    user_id = data.get("user_id")

    if not firebase_url or not user_id:
        return jsonify({"error": "Missing firebase_url or user_id"}), 400

    try:
        audio_data = stream_audio_from_firebase(firebase_url)
        wav_audio = convert_to_wav(audio_data)
        chunks = split_audio(wav_audio)  # default 2-minute chunks (120000 ms)

        whisper = load_whisper()
        diarization_pipeline = load_diarization()

        results = []

        def process_chunk(idx, chunk):
            chunk_id = f"chunk_{idx}"
            log_memory(f"Before chunk {idx}")

            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
                tmp.write(chunk.read())
                chunk_path = tmp.name

            segments, info = whisper.transcribe(chunk_path, word_timestamps=False)
            diarization_segments = diarization_pipeline(chunk_path)
            print(f"🌍 Detected language: {info.language} ({info.language_probability:.2%} confidence)")

            chunk_offset = idx * 120  # 2-minute chunk = 120 seconds

            # Extract timestamped sentences
            sentence_chunks = []
            for seg in segments:
                sentence_chunks.append({
                    "timestamp": [float(seg.start), float(seg.end)],
                    "text": seg.text.strip()
                })

            # Align speakers
            aligner = SpeakerAligner()
            aligned_segments = aligner.align(sentence_chunks, diarization_segments)

            # Offset timestamps
            final_transcript = []
            for spk, start, end, sentence in aligned_segments:
                final_transcript.append({
                    "start": start + chunk_offset,
                    "end": end + chunk_offset,
                    "text": sentence,
                    "speaker": spk
                })

            os.remove(chunk_path)
            log_memory(f"After chunk {idx}")
            return {"chunk_id": chunk_id, "transcript": final_transcript}

        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(process_chunk, idx, chunk) for idx, chunk in enumerate(chunks)]
            for future in as_completed(futures):
                results.append(future.result())

        # Flatten all transcripts
        all_segments = []
        for res in results:
            all_segments.extend(res["transcript"])

        # Sort by start time
        all_segments.sort(key=lambda x: x["start"])

        # Remap speaker labels
        speaker_map = {}
        speaker_counter = 0
        for seg in all_segments:
            local_speaker = seg["speaker"]
            if local_speaker not in speaker_map:
                speaker_map[local_speaker] = f"SPEAKER_{speaker_counter:02d}"
                speaker_counter += 1
            seg["speaker"] = speaker_map[local_speaker]

        # Merge consecutive segments from same speaker
        merged_transcript = []
        for seg in all_segments:
            if (
                merged_transcript and
                merged_transcript[-1]["speaker"] == seg["speaker"] and
                abs(seg["start"] - merged_transcript[-1]["end"]) < 2.0
            ):
                merged_transcript[-1]["end"] = seg["end"]
                merged_transcript[-1]["text"] += " " + seg["text"]
            else:
                merged_transcript.append(seg)

        # Save transcript text to file (optional)
        full_text = "\n".join(f"{seg['speaker']}: {seg['text']}" for seg in merged_transcript)
        save_text_file(f"{user_id}_transcript.txt", full_text)
        print(f"📁 Saved: {user_id}_transcript.txt")

        return jsonify({
            "user_id": user_id,
            "transcript": merged_transcript
        })

    except Exception as e:
        print(f"❌ Error: {e}")
        return jsonify({"error": str(e)}), 500

# --- Run App ---
if __name__ == "__main__":
    app.run(port=8080)
